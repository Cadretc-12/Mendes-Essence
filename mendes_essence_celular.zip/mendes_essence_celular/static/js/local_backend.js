/* =====================================================================
   "Backend" local — roda inteiro no navegador, dentro deste preview.
   É a mesma lógica de app.py (Flask+SQLite), só que guardando os dados
   num objeto em memória persistido pela capability `db` do artifact,
   no lugar de um servidor Flask + arquivo SQLite de verdade.
   ===================================================================== */

const FORMAS_PAGAMENTO_L = ["pix", "cartao", "dinheiro"];
const STATUS_ATENDIMENTO_L = ["agendado", "concluido", "cancelado", "faltou"];
const STATUS_CONTA_L = ["pendente", "paga", "atrasada"];
const ESTADOS_TRAFEGO_L = ["ativo", "pausado", "desativado"];
const MESES_PT_L = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
const RANK_ESTADO_L = { ativo: 0, pausado: 1, desativado: 2 };

function defaultStore() {
  return { clientes: [], procedimentos: [], atendimentos: [], contas: [], trafego: [], metas: { semanal: 0, mensal: 0 }, seq: 1 };
}
let store = defaultStore();
let dbCap = null;

function nextId() { return store.seq++; }
class HttpError extends Error {}
function fail(msg) { throw new HttpError(msg); }

/* ---------------- datas ---------------- */
function fmtISO(d) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; }
function parseISODate(s) { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); }
function addDays(d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); }
function weekBounds(d) { const dow = (d.getDay() + 6) % 7; const seg = addDays(d, -dow); return [seg, addDays(seg, 6)]; }
function monthBounds(d) { return [new Date(d.getFullYear(), d.getMonth(), 1), new Date(d.getFullYear(), d.getMonth() + 1, 0)]; }
function yearBounds(d) { return [new Date(d.getFullYear(), 0, 1), new Date(d.getFullYear(), 11, 31)]; }
function shiftRef(tipo, d, dir) {
  if (tipo === "semana") return addDays(d, 7 * dir);
  if (tipo === "mes") { const nd = new Date(d.getFullYear(), d.getMonth() + dir, 1); const last = new Date(nd.getFullYear(), nd.getMonth() + 1, 0).getDate(); nd.setDate(Math.min(d.getDate(), last)); return nd; }
  if (tipo === "ano") return new Date(d.getFullYear() + dir, d.getMonth(), d.getDate());
}
function monthKeyOfDate(d) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`; }
function mesAnoPt(d) { return `${MESES_PT_L[d.getMonth()]} de ${d.getFullYear()}`; }
const BOUNDS_POR_TIPO_L = { semana: weekBounds, mes: monthBounds, ano: yearBounds };

/* ---------------- clientes ---------------- */
function getOrCreateCliente(nome) {
  nome = (nome || "").trim();
  if (!nome) fail("Nome da cliente é obrigatório");
  let c = store.clientes.find((c) => c.nome.toLowerCase() === nome.toLowerCase());
  if (c) return c.id;
  c = { id: nextId(), nome, criado_em: new Date().toISOString() };
  store.clientes.push(c);
  return c.id;
}

/* ---------------- atendimentos: helpers ---------------- */
function comJoinAtendimento(a) {
  const c = store.clientes.find((x) => x.id === a.cliente_id);
  const p = store.procedimentos.find((x) => x.id === a.procedimento_id);
  return Object.assign({}, a, { cliente_nome: c ? c.nome : "?", procedimento_nome: p ? p.nome : "?" });
}
function checarConflito(a) {
  const [hh, mm] = a.horario.split(":").map(Number);
  const ini = hh * 60 + mm, fim = ini + a.duracao;
  const outros = store.atendimentos.filter((o) => o.data === a.data && o.id !== a.id && (o.status === "agendado" || o.status === "concluido"));
  for (const o of outros) {
    const [oh, om] = o.horario.split(":").map(Number);
    const oIni = oh * 60 + om, oFim = oIni + o.duracao;
    if (ini < oFim && oIni < fim) {
      const c = store.clientes.find((x) => x.id === o.cliente_id);
      return `Esse horário se sobrepõe ao atendimento de ${c ? c.nome : "?"} às ${o.horario}`;
    }
  }
  return null;
}
function validarAtendimento(d, parcial) {
  const erros = [];
  if (!parcial || "procedimento_id" in d) if (!d.procedimento_id) erros.push("Procedimento é obrigatório");
  if (!parcial || "data" in d) if (!d.data) erros.push("Data é obrigatória");
  if (!parcial || "horario" in d) if (!d.horario) erros.push("Horário é obrigatório");
  if (d.forma_pagamento && !FORMAS_PAGAMENTO_L.includes(d.forma_pagamento)) erros.push("Forma de pagamento inválida");
  if (d.status && !STATUS_ATENDIMENTO_L.includes(d.status)) erros.push("Status inválido");
  return erros;
}

/* ---------------- contas: materialização das fixas ---------------- */
function materializarContasFixas(mes) {
  const jaTem = new Set(store.contas.filter((c) => c.mes_referencia === mes && c.fixa).map((c) => c.nome));
  const ultimasPorNome = {};
  store.contas.filter((c) => c.fixa && c.mes_referencia < mes).forEach((c) => {
    if (!ultimasPorNome[c.nome] || ultimasPorNome[c.nome].mes_referencia < c.mes_referencia) ultimasPorNome[c.nome] = c;
  });
  Object.values(ultimasPorNome).forEach((f) => {
    if (!jaTem.has(f.nome)) store.contas.push({ id: nextId(), nome: f.nome, valor: f.valor, fixa: true, mes_referencia: mes, status_pagamento: "pendente" });
  });
}

/* ---------------- dashboard: cálculos ---------------- */
function faturamentoPeriodo(inicio, fim) {
  const ini = fmtISO(inicio), f = fmtISO(fim);
  const rows = store.atendimentos.filter((a) => a.status === "concluido" && a.data >= ini && a.data <= f);
  return { qtd: rows.length, total: rows.reduce((s, a) => s + a.valor, 0) };
}
function evolucaoPeriodo(tipo, inicio, fim) {
  if (tipo === "semana") {
    const dias = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
    return dias.map((label, i) => { const dia = addDays(inicio, i); return { label, valor: faturamentoPeriodo(dia, dia).total }; });
  }
  if (tipo === "mes") {
    const pontos = []; let cursor = inicio, n = 1;
    while (cursor <= fim) {
      const fimSemanaMs = Math.min(addDays(cursor, 6).getTime(), fim.getTime());
      const fimSemana = new Date(fimSemanaMs);
      pontos.push({ label: `Sem ${n}`, valor: faturamentoPeriodo(cursor, fimSemana).total });
      cursor = addDays(fimSemana, 1); n++;
    }
    return pontos;
  }
  if (tipo === "ano") {
    const meses = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
    return meses.map((label, i) => { const [mi, mf] = monthBounds(new Date(inicio.getFullYear(), i, 1)); return { label, valor: faturamentoPeriodo(mi, mf).total }; });
  }
  return [];
}
function diasAtivosNoIntervalo(lanc, inicio, fim) {
  const iniEfetivo = lanc > inicio ? lanc : inicio;
  if (iniEfetivo > fim) return 0;
  return Math.round((fim - iniEfetivo) / 86400000) + 1;
}
function collatePt(a, b) { return a.localeCompare(b, "pt-BR", { sensitivity: "base" }); }

/* ---------------- handlers (espelham cada rota do app.py) ---------------- */

function getClientes(params) {
  const resumo = params.get("resumo") === "1";
  const lista = [...store.clientes].sort((a, b) => collatePt(a.nome, b.nome));
  return lista.map((c) => {
    const item = Object.assign({}, c);
    if (resumo) {
      const rows = store.atendimentos.filter((a) => a.cliente_id === c.id && a.status === "concluido");
      item.total_atendimentos = rows.length;
      item.total_gasto = rows.reduce((s, a) => s + a.valor, 0);
      const ultimo = [...rows].sort((a, b) => b.data.localeCompare(a.data))[0];
      item.ultimo_atendimento = ultimo ? ultimo.data : null;
    }
    return item;
  });
}
function postCliente(body) { const id = getOrCreateCliente(body.nome); return store.clientes.find((c) => c.id === id); }
function putCliente(id, body) {
  const nome = (body.nome || "").trim();
  if (!nome) fail("Nome da cliente é obrigatório");
  const c = store.clientes.find((c) => c.id === id);
  if (!c) fail("Cliente não encontrada");
  c.nome = nome;
  return c;
}
function deleteCliente(id) {
  if (store.atendimentos.some((a) => a.cliente_id === id)) fail("Essa cliente tem atendimentos lançados e não pode ser excluída");
  store.clientes = store.clientes.filter((c) => c.id !== id);
  return { ok: true };
}

function getProcedimentos() { return [...store.procedimentos].sort((a, b) => collatePt(a.nome, b.nome)); }
function postProcedimento(body) {
  const nome = (body.nome || "").trim();
  if (!nome) fail("Nome do procedimento é obrigatório");
  if (store.procedimentos.some((p) => p.nome.toLowerCase() === nome.toLowerCase())) fail("Já existe um procedimento com esse nome");
  const p = { id: nextId(), nome, preco_padrao: Number(body.preco_padrao || 0), duracao_padrao: Number(body.duracao_padrao || 30) };
  store.procedimentos.push(p);
  return p;
}
function putProcedimento(id, body) {
  const p = store.procedimentos.find((p) => p.id === id);
  if (!p) fail("Procedimento não encontrado");
  p.nome = (body.nome || p.nome).trim();
  if (body.preco_padrao !== undefined) p.preco_padrao = Number(body.preco_padrao);
  if (body.duracao_padrao !== undefined) p.duracao_padrao = Number(body.duracao_padrao);
  return p;
}
function deleteProcedimento(id) {
  if (store.atendimentos.some((a) => a.procedimento_id === id)) fail("Esse procedimento já foi usado em atendimentos e não pode ser excluído");
  store.procedimentos = store.procedimentos.filter((p) => p.id !== id);
  return { ok: true };
}

function getAtendimentos(params) {
  let rows = [...store.atendimentos];
  if (params.get("data")) rows = rows.filter((a) => a.data === params.get("data"));
  if (params.get("mes")) rows = rows.filter((a) => a.data.slice(0, 7) === params.get("mes"));
  if (params.get("status")) rows = rows.filter((a) => a.status === params.get("status"));
  rows.sort((a, b) => (a.data === b.data ? a.horario.localeCompare(b.horario) : a.data.localeCompare(b.data)));
  return rows.map(comJoinAtendimento);
}
function postAtendimento(body) {
  if (!(body.cliente_nome || "").trim()) fail("Cliente é obrigatória");
  const erros = validarAtendimento(body, false);
  if (erros.length) fail(erros.join("; "));
  const cliente_id = getOrCreateCliente(body.cliente_nome);
  const a = {
    id: nextId(), cliente_id, procedimento_id: Number(body.procedimento_id),
    data: body.data, horario: body.horario, duracao: Number(body.duracao || 30),
    valor: Number(body.valor || 0), forma_pagamento: body.forma_pagamento || "pix",
    status: body.status || "agendado", notificado_em: null,
  };
  store.atendimentos.push(a);
  const resultado = comJoinAtendimento(a);
  resultado.conflito = checarConflito(a);
  return resultado;
}
function putAtendimento(id, body) {
  const a = store.atendimentos.find((a) => a.id === id);
  if (!a) fail("Atendimento não encontrado");
  const erros = validarAtendimento(body, true);
  if (erros.length) fail(erros.join("; "));
  if (body.cliente_nome) a.cliente_id = getOrCreateCliente(body.cliente_nome);
  if (body.procedimento_id !== undefined) a.procedimento_id = Number(body.procedimento_id);
  if (body.data !== undefined) a.data = body.data;
  if (body.horario !== undefined) a.horario = body.horario;
  if (body.duracao !== undefined) a.duracao = Number(body.duracao);
  if (body.valor !== undefined) a.valor = Number(body.valor);
  if (body.forma_pagamento !== undefined) a.forma_pagamento = body.forma_pagamento;
  if (body.status !== undefined) a.status = body.status;
  const resultado = comJoinAtendimento(a);
  resultado.conflito = checarConflito(a);
  return resultado;
}
function deleteAtendimento(id) { store.atendimentos = store.atendimentos.filter((a) => a.id !== id); return { ok: true }; }
function postNotificado(id) {
  const a = store.atendimentos.find((a) => a.id === id);
  if (a) a.notificado_em = new Date().toISOString();
  return { ok: true };
}

function getAgendaMes(params) {
  const mes = params.get("mes") || monthKeyOfDate(new Date());
  const out = {};
  store.atendimentos.filter((a) => a.data.slice(0, 7) === mes && a.status !== "cancelado").forEach((a) => { out[a.data] = (out[a.data] || 0) + 1; });
  return out;
}
function getAgendaDia(params) {
  const dia = params.get("data") || fmtISO(new Date());
  return store.atendimentos.filter((a) => a.data === dia).sort((a, b) => a.horario.localeCompare(b.horario)).map(comJoinAtendimento);
}
function getAgendaProximos() {
  const hoje = fmtISO(new Date());
  return store.atendimentos.filter((a) => a.data === hoje && a.status === "agendado").map(comJoinAtendimento);
}

function getContas(params) {
  const mes = params.get("mes") || monthKeyOfDate(new Date());
  materializarContasFixas(mes);
  return store.contas.filter((c) => c.mes_referencia === mes).sort((a, b) => collatePt(a.nome, b.nome));
}
function postConta(body) {
  const nome = (body.nome || "").trim();
  if (!nome) fail("Nome da conta é obrigatório");
  const mes = body.mes_referencia || monthKeyOfDate(new Date());
  const c = { id: nextId(), nome, valor: Number(body.valor || 0), fixa: !!body.fixa, mes_referencia: mes, status_pagamento: body.status_pagamento || "pendente" };
  store.contas.push(c);
  return c;
}
function putConta(id, body) {
  const c = store.contas.find((c) => c.id === id);
  if (!c) fail("Conta não encontrada");
  const status = body.status_pagamento !== undefined ? body.status_pagamento : c.status_pagamento;
  if (!STATUS_CONTA_L.includes(status)) fail("Status inválido");
  c.nome = (body.nome || c.nome).trim();
  if (body.valor !== undefined) c.valor = Number(body.valor);
  if (body.fixa !== undefined) c.fixa = !!body.fixa;
  c.status_pagamento = status;
  return c;
}
function deleteConta(id) { store.contas = store.contas.filter((c) => c.id !== id); return { ok: true }; }

function getTrafego(params) {
  const ordenar = params.get("ordenar") || "estado";
  let rows = [...store.trafego];
  if (ordenar === "preco") {
    rows.sort((a, b) => {
      const da = a.estado === "desativado", dbb = b.estado === "desativado";
      if (da !== dbb) return da ? 1 : -1;
      if (b.gasto_diario !== a.gasto_diario) return b.gasto_diario - a.gasto_diario;
      return collatePt(a.nome, b.nome);
    });
  } else if (ordenar === "data") {
    const ap = rows.filter((r) => r.estado !== "desativado").sort((a, b) => b.data_lancamento.localeCompare(a.data_lancamento));
    const de = rows.filter((r) => r.estado === "desativado").sort((a, b) => b.data_lancamento.localeCompare(a.data_lancamento));
    rows = [...ap, ...de];
  } else if (ordenar === "nome") {
    rows.sort((a, b) => {
      const da = a.estado === "desativado", dbb = b.estado === "desativado";
      if (da !== dbb) return da ? 1 : -1;
      return collatePt(a.nome, b.nome);
    });
  } else {
    rows.sort((a, b) => {
      const r = (RANK_ESTADO_L[a.estado] ?? 9) - (RANK_ESTADO_L[b.estado] ?? 9);
      return r !== 0 ? r : collatePt(a.nome, b.nome);
    });
  }
  return rows;
}
function postTrafego(body) {
  const nome = (body.nome || "").trim();
  if (!nome) fail("Nome do público é obrigatório");
  const t = { id: nextId(), nome, gasto_diario: Number(body.gasto_diario || 0), data_lancamento: body.data_lancamento || fmtISO(new Date()), estado: body.estado || "ativo" };
  store.trafego.push(t);
  return t;
}
function putTrafego(id, body) {
  const t = store.trafego.find((t) => t.id === id);
  if (!t) fail("Público não encontrado");
  const estado = body.estado !== undefined ? body.estado : t.estado;
  if (!ESTADOS_TRAFEGO_L.includes(estado)) fail("Estado inválido");
  t.nome = (body.nome || t.nome).trim();
  if (body.gasto_diario !== undefined) t.gasto_diario = Number(body.gasto_diario);
  t.estado = estado;
  return t;
}
function deleteTrafego(id) { store.trafego = store.trafego.filter((t) => t.id !== id); return { ok: true }; }

function getMetas() { return Object.assign({}, store.metas); }
function putMetas(body) {
  if (body.semanal !== undefined) store.metas.semanal = Number(body.semanal);
  if (body.mensal !== undefined) store.metas.mensal = Number(body.mensal);
  return Object.assign({}, store.metas);
}

function getDashPeriodo(params) {
  const tipo = params.get("tipo") || "mes";
  if (!BOUNDS_POR_TIPO_L[tipo]) fail("tipo inválido");
  const ref = params.get("ref") ? parseISODate(params.get("ref")) : new Date();
  const [inicio, fim] = BOUNDS_POR_TIPO_L[tipo](ref);
  const { qtd, total } = faturamentoPeriodo(inicio, fim);
  let meta = null, metaEstimada = false;
  if (tipo === "semana") meta = store.metas.semanal;
  else if (tipo === "mes") meta = store.metas.mensal;
  else if (tipo === "ano") { meta = store.metas.mensal * 12; metaEstimada = true; }
  let label;
  if (tipo === "semana") label = `${String(inicio.getDate()).padStart(2, "0")}/${String(inicio.getMonth() + 1).padStart(2, "0")} a ${String(fim.getDate()).padStart(2, "0")}/${String(fim.getMonth() + 1).padStart(2, "0")}`;
  else if (tipo === "mes") label = mesAnoPt(inicio);
  else label = String(inicio.getFullYear());
  return {
    tipo, inicio: fmtISO(inicio), fim: fmtISO(fim), label,
    faturamento: total, qtd_atendimentos: qtd, meta, meta_estimada: metaEstimada,
    bateu_meta: meta ? total >= meta : null,
    evolucao: evolucaoPeriodo(tipo, inicio, fim),
    ref: fmtISO(ref), prev_ref: fmtISO(shiftRef(tipo, ref, -1)), next_ref: fmtISO(shiftRef(tipo, ref, 1)),
  };
}
function getDashClientes(params) {
  const ref = params.get("ref") ? parseISODate(params.get("ref")) : new Date();
  const periodos = { semana: weekBounds(ref), mes: monthBounds(ref), ano: yearBounds(ref) };
  const resultado = [];
  store.clientes.forEach((c) => {
    const item = { cliente_id: c.id, nome: c.nome };
    Object.entries(periodos).forEach(([chave, bounds]) => {
      const [ini, fim] = bounds;
      const iniS = fmtISO(ini), fimS = fmtISO(fim);
      const rows = store.atendimentos.filter((a) => a.cliente_id === c.id && a.status === "concluido" && a.data >= iniS && a.data <= fimS);
      item[chave] = { qtd: rows.length, valor: rows.reduce((s, a) => s + a.valor, 0) };
    });
    if (item.ano.qtd > 0) resultado.push(item);
  });
  resultado.sort((a, b) => b.mes.valor - a.mes.valor);
  return { ref: fmtISO(ref), clientes: resultado };
}
function getDashProcedimentos(params) {
  const ref = params.get("ref") ? parseISODate(params.get("ref")) : new Date();
  const periodos = { semana: weekBounds(ref), mes: monthBounds(ref), ano: yearBounds(ref) };
  const resultado = [];
  store.procedimentos.forEach((p) => {
    const item = { procedimento_id: p.id, nome: p.nome };
    Object.entries(periodos).forEach(([chave, bounds]) => {
      const [ini, fim] = bounds;
      const iniS = fmtISO(ini), fimS = fmtISO(fim);
      const rows = store.atendimentos.filter((a) => a.procedimento_id === p.id && a.status === "concluido" && a.data >= iniS && a.data <= fimS);
      item[chave] = { qtd: rows.length, valor: rows.reduce((s, a) => s + a.valor, 0) };
    });
    if (item.ano.qtd > 0) resultado.push(item);
  });
  resultado.sort((a, b) => b.mes.valor - a.mes.valor);
  return { ref: fmtISO(ref), procedimentos: resultado };
}
function getDashFinanceiro(params) {
  const mes = params.get("mes") || monthKeyOfDate(new Date());
  const ref = parseISODate(mes + "-01");
  const [inicio, fim] = monthBounds(ref);
  const hoje = new Date();
  const hojeD = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate());
  const fimRealizado = inicio <= hojeD ? (hojeD < fim ? hojeD : fim) : addDays(inicio, -1);

  materializarContasFixas(mes);
  const receita = faturamentoPeriodo(inicio, fim).total;

  const contas = store.contas.filter((c) => c.mes_referencia === mes);
  const contasPagas = contas.filter((c) => c.status_pagamento === "paga").reduce((s, c) => s + c.valor, 0);
  const contasTodas = contas.reduce((s, c) => s + c.valor, 0);

  const trafegoAtivo = store.trafego.filter((t) => t.estado === "ativo");
  let trafegoAtual = 0, trafegoProjetado = 0;
  trafegoAtivo.forEach((t) => {
    const lanc = parseISODate(t.data_lancamento);
    trafegoProjetado += t.gasto_diario * diasAtivosNoIntervalo(lanc, inicio, fim);
    if (fimRealizado >= inicio) trafegoAtual += t.gasto_diario * diasAtivosNoIntervalo(lanc, inicio, fimRealizado);
  });

  const despesasAtuais = contasPagas + trafegoAtual;
  const despesasProjetadas = contasTodas + trafegoProjetado;

  return {
    mes, receita,
    contas_pagas: contasPagas, contas_total: contasTodas,
    trafego_pago_atual: Math.round(trafegoAtual * 100) / 100,
    trafego_pago_projetado: Math.round(trafegoProjetado * 100) / 100,
    despesas_atuais: Math.round(despesasAtuais * 100) / 100,
    despesas_projetadas: Math.round(despesasProjetadas * 100) / 100,
    lucro_atual: Math.round((receita - despesasAtuais) * 100) / 100,
    lucro_projetado: Math.round((receita - despesasProjetadas) * 100) / 100,
    prev_mes: monthKeyOfDate(shiftRef("mes", ref, -1)),
    next_mes: monthKeyOfDate(shiftRef("mes", ref, 1)),
  };
}

/* ---------------- roteador ---------------- */

function dispatch(method, segs, params, body) {
  if (segs[0] === "clientes" && segs.length === 1) { if (method === "GET") return getClientes(params); if (method === "POST") return postCliente(body); }
  if (segs[0] === "clientes" && segs.length === 2) { const id = Number(segs[1]); if (method === "PUT") return putCliente(id, body); if (method === "DELETE") return deleteCliente(id); }
  if (segs[0] === "procedimentos" && segs.length === 1) { if (method === "GET") return getProcedimentos(); if (method === "POST") return postProcedimento(body); }
  if (segs[0] === "procedimentos" && segs.length === 2) { const id = Number(segs[1]); if (method === "PUT") return putProcedimento(id, body); if (method === "DELETE") return deleteProcedimento(id); }
  if (segs[0] === "atendimentos" && segs.length === 1) { if (method === "GET") return getAtendimentos(params); if (method === "POST") return postAtendimento(body); }
  if (segs[0] === "atendimentos" && segs.length === 3 && segs[2] === "notificado") return postNotificado(Number(segs[1]));
  if (segs[0] === "atendimentos" && segs.length === 2) { const id = Number(segs[1]); if (method === "PUT") return putAtendimento(id, body); if (method === "DELETE") return deleteAtendimento(id); }
  if (segs[0] === "agenda" && segs[1] === "mes") return getAgendaMes(params);
  if (segs[0] === "agenda" && segs[1] === "dia") return getAgendaDia(params);
  if (segs[0] === "agenda" && segs[1] === "proximos") return getAgendaProximos();
  if (segs[0] === "contas" && segs.length === 1) { if (method === "GET") return getContas(params); if (method === "POST") return postConta(body); }
  if (segs[0] === "contas" && segs.length === 2) { const id = Number(segs[1]); if (method === "PUT") return putConta(id, body); if (method === "DELETE") return deleteConta(id); }
  if (segs[0] === "trafego" && segs.length === 1) { if (method === "GET") return getTrafego(params); if (method === "POST") return postTrafego(body); }
  if (segs[0] === "trafego" && segs.length === 2) { const id = Number(segs[1]); if (method === "PUT") return putTrafego(id, body); if (method === "DELETE") return deleteTrafego(id); }
  if (segs[0] === "metas") { if (method === "GET") return getMetas(); if (method === "PUT") return putMetas(body); }
  if (segs[0] === "dashboard" && segs[1] === "periodo") return getDashPeriodo(params);
  if (segs[0] === "dashboard" && segs[1] === "clientes") return getDashClientes(params);
  if (segs[0] === "dashboard" && segs[1] === "procedimentos") return getDashProcedimentos(params);
  if (segs[0] === "dashboard" && segs[1] === "financeiro") return getDashFinanceiro(params);
  fail("Rota não encontrada: " + method + " " + segs.join("/"));
}

async function localApi(path, opts) {
  const method = (opts.method || "GET").toUpperCase();
  const body = opts.body ? JSON.parse(opts.body) : {};
  const [routePath, qs] = path.split("?");
  const params = new URLSearchParams(qs || "");
  const segs = routePath.split("/").filter(Boolean);
  let result;
  try {
    result = dispatch(method, segs, params, body);
  } catch (e) {
    throw new Error(e.message || "Não foi possível concluir a ação.");
  }
  schedulePersist();
  return result;
}

/* ---------------- persistência (localStorage do próprio aparelho) ---------------- */
/* Cada aparelho guarda a sua própria cópia dos dados, aqui mesmo no navegador/app
   instalado — sem depender de servidor nenhum. É por isso que celular e computador
   não veem os mesmos dados: essa foi a opção escolhida (independência entre eles). */

const CHAVE_ARMAZENAMENTO = "mendes_essence_dados_v1";

async function loadStore() {
  try {
    const bruto = localStorage.getItem(CHAVE_ARMAZENAMENTO);
    if (bruto) store = Object.assign(defaultStore(), JSON.parse(bruto));
  } catch (e) { /* mantém store padrão se der erro de leitura */ }
}

async function persistNow() {
  try { localStorage.setItem(CHAVE_ARMAZENAMENTO, JSON.stringify(store)); }
  catch (e) { /* armazenamento cheio ou bloqueado — falha silenciosa */ }
}

let persistTimer = null;
function schedulePersist() {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(persistNow, 250);
}
