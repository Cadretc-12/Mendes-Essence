"use strict";

/* ============================================================
   Studio Mendes Essence — frontend
   SPA em JS puro. Cada view renderiza dentro de #view-root.
   ============================================================ */

const STATUS_ATENDIMENTO_LABEL = { agendado: "Agendado", concluido: "Concluído", cancelado: "Cancelado", faltou: "Faltou" };
const STATUS_CONTA_LABEL = { pendente: "Pendente", paga: "Paga", atrasada: "Atrasada" };
const ESTADO_TRAFEGO_LABEL = { ativo: "Ativo", pausado: "Pausado", desativado: "Desativado" };
const PAGAMENTO_LABEL = { pix: "Pix", cartao: "Cartão", dinheiro: "Dinheiro" };

const ICON_PLUS = '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
const ICON_EDIT = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M4 20l.9-3.8L16.2 4.9a1.5 1.5 0 0 1 2.1 0l.8.8a1.5 1.5 0 0 1 0 2.1L7.8 19.1 4 20Z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>';
const ICON_TRASH = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M5 7h14M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m-9 0 1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const ICON_L = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const ICON_R = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';

/* ---------------- utilidades ---------------- */

async function api(path, opts) {
  opts = opts || {};
  return await localApi(path, opts);
}
function setOnline(ok) { /* sempre "online" — os dados são só deste aparelho */ }

function fmtBRL(v) {
  return (Number(v) || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
function fmtData(iso) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}
function todayISO() { return new Date().toISOString().slice(0, 10); }
function monthKeyOf(d) { return d.toISOString().slice(0, 7); }
function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

function toast(msg, tipo) {
  const root = document.getElementById("toast-root");
  const el = document.createElement("div");
  el.className = "toast" + (tipo === "erro" ? " erro" : "");
  el.textContent = msg;
  root.appendChild(el);
  setTimeout(() => el.remove(), 3600);
}

/* ---------------- modal ---------------- */

function closeModal() {
  const root = document.getElementById("modal-root");
  root.innerHTML = "";
}

function openModal(title, bodyEl) {
  const root = document.getElementById("modal-root");
  root.innerHTML = "";
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.addEventListener("mousedown", (e) => { if (e.target === overlay) closeModal(); });
  const modal = document.createElement("div");
  modal.className = "modal";
  const head = document.createElement("div");
  head.className = "modal-head";
  head.innerHTML = `<h2>${escapeHtml(title)}</h2><button class="modal-close" type="button" aria-label="Fechar">
    <svg viewBox="0 0 24 24" width="18" height="18"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>`;
  head.querySelector(".modal-close").addEventListener("click", closeModal);
  modal.appendChild(head);
  modal.appendChild(bodyEl);
  overlay.appendChild(modal);
  root.appendChild(overlay);
  document.addEventListener("keydown", escCloseOnce);
}
function escCloseOnce(e) {
  if (e.key === "Escape") { closeModal(); document.removeEventListener("keydown", escCloseOnce); }
}

function confirmar(msg) {
  return new Promise((resolve) => {
    const body = document.createElement("div");
    body.innerHTML = `<p>${escapeHtml(msg)}</p>
      <div class="modal-actions">
        <button class="btn btn-secondary" id="conf-no" type="button">Cancelar</button>
        <button class="btn btn-danger" id="conf-yes" type="button">Excluir</button>
      </div>`;
    openModal("Confirmar", body);
    body.querySelector("#conf-no").addEventListener("click", () => { closeModal(); resolve(false); });
    body.querySelector("#conf-yes").addEventListener("click", () => { closeModal(); resolve(true); });
  });
}

/* ---------------- autocomplete ---------------- */

function attachAutocomplete(input, list, opts) {
  // opts: {getItems():[], labelKey, onSelect(item), onClear()}
  function render(filtered) {
    if (!filtered.length) { list.classList.add("hidden"); list.innerHTML = ""; return; }
    list.innerHTML = filtered.slice(0, 30).map((it, i) =>
      `<button type="button" data-i="${i}">${escapeHtml(it[opts.labelKey])}</button>`).join("");
    list.classList.remove("hidden");
    Array.from(list.children).forEach((btn, i) => {
      btn.addEventListener("mousedown", (e) => {
        e.preventDefault();
        opts.onSelect(filtered[i]);
        list.classList.add("hidden");
      });
    });
  }
  input.addEventListener("input", () => {
    if (opts.onClear) opts.onClear();
    const q = input.value.trim().toLowerCase();
    const all = opts.getItems();
    render(q ? all.filter((it) => it[opts.labelKey].toLowerCase().includes(q)) : all);
  });
  input.addEventListener("focus", () => input.dispatchEvent(new Event("input")));
  input.addEventListener("blur", () => setTimeout(() => list.classList.add("hidden"), 130));
  list.classList.add("hidden");
}

/* ---------------- caches (clientes / procedimentos) ---------------- */

let cacheClientes = [];
let cacheProcedimentos = [];

async function refreshClientes() { cacheClientes = await api("/clientes"); return cacheClientes; }
async function refreshProcedimentos() { cacheProcedimentos = await api("/procedimentos"); return cacheProcedimentos; }

/* ============================================================
   Navegação
   ============================================================ */

const VIEWS = {
  dashboard: { title: "Dashboard", render: renderDashboard },
  atendimentos: { title: "Atendimentos", render: renderAtendimentos },
  agenda: { title: "Agenda", render: renderAgenda },
  trafego: { title: "Tráfego pago", render: renderTrafego },
  procedimentos: { title: "Procedimentos", render: renderProcedimentos },
  clientes: { title: "Clientes", render: renderClientes },
  contas: { title: "Contas a pagar", render: renderContas },
};

function goTo(view) {
  document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  document.getElementById("view-title").textContent = VIEWS[view].title;
  document.getElementById("topbar-actions").innerHTML = "";
  document.getElementById("view-root").innerHTML = "";
  closeSidebarMobile();
  VIEWS[view].render();
}

function closeSidebarMobile() {
  document.getElementById("sidebar").classList.remove("open");
  document.getElementById("sidebar-scrim").classList.remove("show");
}

/* ============================================================
   DASHBOARD
   ============================================================ */

let dashState = { tab: "mes", ref: todayISO(), mes: monthKeyOf(new Date()) };

function renderDashboard() {
  const root = document.getElementById("view-root");
  root.innerHTML = `
    <div class="tabs" id="dash-tabs">
      <button data-tab="semana">Semanal</button>
      <button data-tab="mes">Mensal</button>
      <button data-tab="ano">Anual</button>
      <button data-tab="clientes">Clientes</button>
      <button data-tab="procedimentos">Procedimentos</button>
      <button data-tab="financeiro">Financeiro</button>
    </div>
    <div id="dash-body" class="stack-gap" style="margin-top:18px;"></div>`;
  root.querySelectorAll("#dash-tabs button").forEach((b) => {
    b.classList.toggle("active", b.dataset.tab === dashState.tab);
    b.addEventListener("click", () => { dashState.tab = b.dataset.tab; renderDashboard(); });
  });
  const body = document.getElementById("dash-body");
  if (["semana", "mes", "ano"].includes(dashState.tab)) renderDashPeriodo(body, dashState.tab);
  else if (dashState.tab === "clientes") renderDashListaPeriodos(body, "clientes");
  else if (dashState.tab === "procedimentos") renderDashListaPeriodos(body, "procedimentos");
  else renderDashFinanceiro(body);
}

async function renderDashPeriodo(body, tipo) {
  body.innerHTML = `<p class="empty-state">Carregando…</p>`;
  let d;
  try { d = await api(`/dashboard/periodo?tipo=${tipo}&ref=${dashState.ref}`); }
  catch (e) { body.innerHTML = `<p class="form-error">${escapeHtml(e.message)}</p>`; return; }

  const metaEditavel = tipo !== "ano";
  const bateu = d.meta ? d.faturamento >= d.meta : null;
  const pct = d.meta ? Math.min(100, Math.round((d.faturamento / d.meta) * 100)) : 0;

  body.innerHTML = `
    <div class="row-between">
      <div class="period-nav">
        <button id="dp-prev" type="button">${ICON_L}</button>
        <span class="period-label">${escapeHtml(capitalize(d.label))}</span>
        <button id="dp-next" type="button">${ICON_R}</button>
      </div>
      <button id="dp-hoje" class="btn btn-secondary" type="button">Hoje</button>
    </div>

    <div class="meta-box">
      <div class="meta-info">
        <div class="meta-label">Meta ${tipo === "semana" ? "semanal" : tipo === "mes" ? "mensal" : "anual (estimada, 12× a meta mensal)"}</div>
        <div class="meta-value" id="meta-display">${d.meta ? fmtBRL(d.meta) : "sem meta definida"}</div>
        <div class="progress-bar ${bateu ? "bateu" : ""}"><span style="width:${pct}%"></span></div>
      </div>
      ${metaEditavel ? `<button id="meta-edit-btn" class="btn btn-secondary" type="button">${ICON_EDIT} Editar meta</button>` : ""}
    </div>

    <div class="kpi-grid">
      <div class="kpi ${bateu === true ? "positivo" : bateu === false ? "negativo" : ""}">
        <div class="kpi-label">Faturamento</div>
        <div class="kpi-value">${fmtBRL(d.faturamento)}</div>
        <div class="kpi-sub">${bateu === null ? "sem meta cadastrada" : bateu ? "meta batida" : "meta não batida"}</div>
      </div>
      <div class="kpi">
        <div class="kpi-label">Atendimentos concluídos</div>
        <div class="kpi-value">${d.qtd_atendimentos}</div>
      </div>
    </div>

    <div class="card">
      <h3 style="margin-bottom:14px;">Evolução no período</h3>
      ${d.evolucao.some((p) => p.valor > 0) ? svgEvolucao(d.evolucao) : `<p class="faint">Sem faturamento concluído nesse período ainda.</p>`}
    </div>`;

  document.getElementById("dp-prev").addEventListener("click", () => { dashState.ref = d.prev_ref; renderDashboard(); });
  document.getElementById("dp-next").addEventListener("click", () => { dashState.ref = d.next_ref; renderDashboard(); });
  document.getElementById("dp-hoje").addEventListener("click", () => { dashState.ref = todayISO(); renderDashboard(); });
  if (metaEditavel) document.getElementById("meta-edit-btn").addEventListener("click", () => editarMetaModal(tipo));
}

function editarMetaModal(tipo) {
  const campo = tipo === "semana" ? "semanal" : "mensal";
  const body = document.createElement("div");
  body.innerHTML = `
    <div class="field"><label>Valor da meta ${campo}</label>
      <input type="number" step="0.01" min="0" id="meta-input" placeholder="0,00"></div>
    <div class="modal-actions">
      <button class="btn btn-secondary" type="button" id="meta-cancel">Cancelar</button>
      <button class="btn btn-primary" type="button" id="meta-save">Salvar</button>
    </div>`;
  openModal("Editar meta", body);
  body.querySelector("#meta-cancel").addEventListener("click", closeModal);
  body.querySelector("#meta-save").addEventListener("click", async () => {
    const v = parseFloat(body.querySelector("#meta-input").value || "0");
    try {
      await api("/metas", { method: "PUT", body: JSON.stringify({ [campo]: v }) });
      closeModal(); toast("Meta atualizada"); renderDashboard();
    } catch (e) { toast(e.message, "erro"); }
  });
}

async function renderDashListaPeriodos(body, tipo) {
  body.innerHTML = `<p class="empty-state">Carregando…</p>`;
  let d;
  try { d = await api(`/dashboard/${tipo}?ref=${dashState.ref}`); }
  catch (e) { body.innerHTML = `<p class="form-error">${escapeHtml(e.message)}</p>`; return; }
  const itens = tipo === "clientes" ? d.clientes : d.procedimentos;
  const nomeCol = tipo === "clientes" ? "Cliente" : "Procedimento";

  if (!itens.length) {
    body.innerHTML = emptyState(tipo === "clientes" ? "Nenhuma cliente com atendimento concluído ainda." : "Nenhum procedimento com atendimento concluído ainda.");
    return;
  }

  body.innerHTML = `
    <div class="row-between">
      <div class="field" style="margin:0; max-width:200px;">
        <label>Ver a partir de</label>
        <input type="date" id="ref-picker" value="${d.ref}">
      </div>
      <button id="ref-hoje" class="btn btn-secondary" type="button">Hoje</button>
    </div>
    <div class="table-wrap" style="margin-top:14px;">
      <table>
        <thead><tr><th>${nomeCol}</th><th class="num">Semana</th><th class="num">Mês</th><th class="num">Ano</th></tr></thead>
        <tbody>
          ${itens.map((it) => `<tr>
            <td>${escapeHtml(it.nome)}</td>
            <td class="num">${fmtBRL(it.semana.valor)}<br><span class="faint">${it.semana.qtd}x</span></td>
            <td class="num">${fmtBRL(it.mes.valor)}<br><span class="faint">${it.mes.qtd}x</span></td>
            <td class="num">${fmtBRL(it.ano.valor)}<br><span class="faint">${it.ano.qtd}x</span></td>
          </tr>`).join("")}
        </tbody>
      </table>
    </div>`;
  document.getElementById("ref-picker").addEventListener("change", (e) => { dashState.ref = e.target.value; renderDashboard(); });
  document.getElementById("ref-hoje").addEventListener("click", () => { dashState.ref = todayISO(); renderDashboard(); });
}

async function renderDashFinanceiro(body) {
  body.innerHTML = `<p class="empty-state">Carregando…</p>`;
  let d;
  try { d = await api(`/dashboard/financeiro?mes=${dashState.mes}`); }
  catch (e) { body.innerHTML = `<p class="form-error">${escapeHtml(e.message)}</p>`; return; }

  const [y, m] = d.mes.split("-");
  const label = new Date(+y, +m - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  body.innerHTML = `
    <div class="period-nav">
      <button id="fin-prev" type="button">${ICON_L}</button>
      <span class="period-label">${escapeHtml(capitalize(label))}</span>
      <button id="fin-next" type="button">${ICON_R}</button>
    </div>
    <div class="kpi-grid">
      <div class="kpi"><div class="kpi-label">Receita do mês</div><div class="kpi-value">${fmtBRL(d.receita)}</div></div>
      <div class="kpi ${d.lucro_atual >= 0 ? "positivo" : "negativo"}"><div class="kpi-label">Lucro atual (contas já pagas)</div><div class="kpi-value">${fmtBRL(d.lucro_atual)}</div></div>
      <div class="kpi ${d.lucro_projetado >= 0 ? "positivo" : "negativo"}"><div class="kpi-label">Lucro projetado (fim do mês)</div><div class="kpi-value">${fmtBRL(d.lucro_projetado)}</div></div>
    </div>
    <div class="card">
      <h3 style="margin-bottom:12px;">Despesas do mês</h3>
      <table>
        <tbody>
          <tr><td>Contas a pagar já pagas</td><td class="num">${fmtBRL(d.contas_pagas)}</td></tr>
          <tr><td>Contas a pagar (todas, pagas + pendentes)</td><td class="num">${fmtBRL(d.contas_total)}</td></tr>
          <tr><td>Tráfego pago até hoje</td><td class="num">${fmtBRL(d.trafego_pago_atual)}</td></tr>
          <tr><td>Tráfego pago projetado (mês inteiro)</td><td class="num">${fmtBRL(d.trafego_pago_projetado)}</td></tr>
        </tbody>
      </table>
      <p class="faint" style="margin-top:12px;">O tráfego pago considera só os públicos ativos hoje — se um público foi pausado no meio do mês, esse cálculo ainda conta os dias anteriores à pausa como ativos.</p>
    </div>`;

  document.getElementById("fin-prev").addEventListener("click", () => { dashState.mes = d.prev_mes; renderDashboard(); });
  document.getElementById("fin-next").addEventListener("click", () => { dashState.mes = d.next_mes; renderDashboard(); });
}

function fmtBRLCurto(v) {
  v = Number(v) || 0;
  if (Math.abs(v) >= 1000) return "R$" + (v / 1000).toLocaleString("pt-BR", { maximumFractionDigits: 1 }) + "k";
  return "R$" + v.toLocaleString("pt-BR", { maximumFractionDigits: 0 });
}

function svgEvolucao(pontos) {
  const w = 640, h = 220, padBottom = 24, padTop = 22, padX = 8, gap = 10;
  const n = Math.max(1, pontos.length);
  const max = Math.max(1, ...pontos.map((p) => p.valor));
  const barW = (w - padX * 2 - gap * (n - 1)) / n;
  const usableH = h - padTop - padBottom;
  let bars = "";
  pontos.forEach((p, i) => {
    const bh = (p.valor / max) * usableH;
    const x = padX + i * (barW + gap);
    const y = padTop + (usableH - bh);
    bars += `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(bh, p.valor > 0 ? 3 : 0).toFixed(1)}" rx="4" fill="#586050">
      <title>${escapeHtml(p.label)}: ${fmtBRL(p.valor)}</title>
    </rect>`;
    if (p.valor > 0) {
      bars += `<text x="${(x + barW / 2).toFixed(1)}" y="${(y - 7).toFixed(1)}" text-anchor="middle" font-size="10.5" font-family="Work Sans, sans-serif" fill="#33362C">${fmtBRLCurto(p.valor)}</text>`;
    }
    bars += `<text x="${(x + barW / 2).toFixed(1)}" y="${h - 6}" text-anchor="middle" font-size="11" font-family="Work Sans, sans-serif" fill="#A39A7E">${escapeHtml(p.label)}</text>`;
  });
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" role="img" aria-label="Evolução do faturamento no período" preserveAspectRatio="xMidYMid meet">
    <line x1="${padX}" y1="${h - padBottom}" x2="${w - padX}" y2="${h - padBottom}" stroke="#C6D2B7" stroke-width="1"/>
    ${bars}
  </svg>`;
}

function emptyState(msg) {
  return `<div class="empty-state">
    <svg viewBox="0 0 24 24" width="34" height="34"><path d="M12 3c2 2.5 5 5 5 8.5A5 5 0 0 1 7 11.5C7 8 10 5.5 12 3Z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>
    <p>${escapeHtml(msg)}</p>
  </div>`;
}

/* ============================================================
   ATENDIMENTOS
   ============================================================ */

let atMes = monthKeyOf(new Date());

async function renderAtendimentos() {
  document.getElementById("topbar-actions").innerHTML =
    `<button class="btn btn-primary" id="novo-atendimento">${ICON_PLUS} Novo atendimento</button>`;
  document.getElementById("novo-atendimento").addEventListener("click", () => abrirFormAtendimento());

  const root = document.getElementById("view-root");
  root.innerHTML = `
    <div class="row-between" style="margin-bottom:14px;">
      <div class="period-nav">
        <button id="at-prev" type="button">${ICON_L}</button>
        <span class="period-label" id="at-label"></span>
        <button id="at-next" type="button">${ICON_R}</button>
      </div>
    </div>
    <div id="at-list"></div>`;

  document.getElementById("at-prev").addEventListener("click", () => { atMes = addMonthKey(atMes, -1); renderAtendimentos(); });
  document.getElementById("at-next").addEventListener("click", () => { atMes = addMonthKey(atMes, 1); renderAtendimentos(); });

  const [y, m] = atMes.split("-");
  document.getElementById("at-label").textContent = capitalize(new Date(+y, +m - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" }));

  await Promise.all([refreshClientes(), refreshProcedimentos()]);
  const lista = document.getElementById("at-list");
  let itens;
  try { itens = await api(`/atendimentos?mes=${atMes}`); }
  catch (e) { lista.innerHTML = `<p class="form-error">${escapeHtml(e.message)}</p>`; return; }

  if (!itens.length) { lista.innerHTML = emptyState("Nenhum atendimento lançado nesse mês ainda."); return; }

  lista.innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Data</th><th>Hora</th><th>Cliente</th><th>Procedimento</th><th class="num">Valor</th><th>Pagamento</th><th>Status</th><th></th></tr></thead>
    <tbody>${itens.map(rowAtendimento).join("")}</tbody>
  </table></div>`;

  lista.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => abrirFormAtendimento(itens.find((i) => i.id == b.dataset.edit))));
  lista.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", async () => {
    if (await confirmar("Excluir esse atendimento?")) {
      try { await api(`/atendimentos/${b.dataset.del}`, { method: "DELETE" }); toast("Atendimento excluído"); renderAtendimentos(); }
      catch (e) { toast(e.message, "erro"); }
    }
  }));
}

function rowAtendimento(a) {
  return `<tr>
    <td>${fmtData(a.data)}</td>
    <td>${a.horario}</td>
    <td>${escapeHtml(a.cliente_nome)}</td>
    <td>${escapeHtml(a.procedimento_nome)}</td>
    <td class="num">${fmtBRL(a.valor)}</td>
    <td>${PAGAMENTO_LABEL[a.forma_pagamento] || a.forma_pagamento}</td>
    <td><span class="chip status-${a.status}">${STATUS_ATENDIMENTO_LABEL[a.status]}</span></td>
    <td style="white-space:nowrap;">
      <button class="btn btn-icon btn-secondary" data-edit="${a.id}" type="button" aria-label="Editar">${ICON_EDIT}</button>
      <button class="btn btn-icon btn-secondary" data-del="${a.id}" type="button" aria-label="Excluir">${ICON_TRASH}</button>
    </td>
  </tr>`;
}

function addMonthKey(key, delta) {
  const [y, m] = key.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return monthKeyOf(d);
}

function abrirFormAtendimento(atendimento, dataFixa) {
  const editando = !!atendimento;
  let procedimentoSelecionado = editando ? { id: atendimento.procedimento_id, nome: atendimento.procedimento_nome } : null;

  const body = document.createElement("div");
  body.innerHTML = `
    <div id="at-form-erro" class="form-error hidden"></div>
    <div id="at-form-aviso" class="form-warning hidden"></div>
    <div class="field autocomplete">
      <label>Cliente</label>
      <input type="text" id="f-cliente" autocomplete="off" value="${escapeHtml(editando ? atendimento.cliente_nome : "")}" placeholder="Digite para buscar ou cadastrar">
      <div class="autocomplete-list" id="f-cliente-list"></div>
    </div>
    <div class="field autocomplete">
      <label>Procedimento</label>
      <input type="text" id="f-procedimento" autocomplete="off" value="${escapeHtml(editando ? atendimento.procedimento_nome : "")}" placeholder="Selecione um procedimento do catálogo">
      <div class="autocomplete-list" id="f-procedimento-list"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Data</label><input type="date" id="f-data" value="${editando ? atendimento.data : (dataFixa || todayISO())}"></div>
      <div class="field"><label>Horário</label><input type="time" id="f-horario" value="${editando ? atendimento.horario : "09:00"}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Duração (min)</label><input type="number" min="5" step="5" id="f-duracao" value="${editando ? atendimento.duracao : 30}"></div>
      <div class="field"><label>Valor (R$)</label><input type="number" min="0" step="0.01" id="f-valor" value="${editando ? atendimento.valor : ""}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Forma de pagamento</label>
        <select id="f-pagamento">${Object.entries(PAGAMENTO_LABEL).map(([k, v]) => `<option value="${k}" ${editando && atendimento.forma_pagamento === k ? "selected" : ""}>${v}</option>`).join("")}</select>
      </div>
      <div class="field"><label>Status</label>
        <select id="f-status">${Object.entries(STATUS_ATENDIMENTO_LABEL).map(([k, v]) => `<option value="${k}" ${(editando ? atendimento.status : "agendado") === k ? "selected" : ""}>${v}</option>`).join("")}</select>
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" type="button" id="f-cancel">Cancelar</button>
      <button class="btn btn-primary" type="button" id="f-save">${editando ? "Salvar" : "Lançar atendimento"}</button>
    </div>`;
  openModal(editando ? "Editar atendimento" : "Novo atendimento", body);

  attachAutocomplete(body.querySelector("#f-cliente"), body.querySelector("#f-cliente-list"), {
    getItems: () => cacheClientes, labelKey: "nome",
    onSelect: (it) => { body.querySelector("#f-cliente").value = it.nome; },
  });

  attachAutocomplete(body.querySelector("#f-procedimento"), body.querySelector("#f-procedimento-list"), {
    getItems: () => cacheProcedimentos, labelKey: "nome",
    onSelect: (it) => {
      body.querySelector("#f-procedimento").value = it.nome;
      procedimentoSelecionado = it;
      body.querySelector("#f-valor").value = it.preco_padrao;
      body.querySelector("#f-duracao").value = it.duracao_padrao;
    },
    onClear: () => { procedimentoSelecionado = null; },
  });
  body.querySelector("#f-procedimento").addEventListener("input", (e) => {
    const match = cacheProcedimentos.find((p) => p.nome.toLowerCase() === e.target.value.trim().toLowerCase());
    procedimentoSelecionado = match || null;
  });

  body.querySelector("#f-cancel").addEventListener("click", closeModal);
  body.querySelector("#f-save").addEventListener("click", async () => {
    const erroEl = body.querySelector("#at-form-erro");
    erroEl.classList.add("hidden");
    const clienteNome = body.querySelector("#f-cliente").value.trim();
    if (!clienteNome) { erroEl.textContent = "Informe a cliente."; erroEl.classList.remove("hidden"); return; }
    if (!procedimentoSelecionado) { erroEl.textContent = "Selecione um procedimento do catálogo."; erroEl.classList.remove("hidden"); return; }

    const payload = {
      cliente_nome: clienteNome,
      procedimento_id: procedimentoSelecionado.id,
      data: body.querySelector("#f-data").value,
      horario: body.querySelector("#f-horario").value,
      duracao: parseInt(body.querySelector("#f-duracao").value || "30", 10),
      valor: parseFloat(body.querySelector("#f-valor").value || "0"),
      forma_pagamento: body.querySelector("#f-pagamento").value,
      status: body.querySelector("#f-status").value,
    };
    try {
      const resultado = editando
        ? await api(`/atendimentos/${atendimento.id}`, { method: "PUT", body: JSON.stringify(payload) })
        : await api("/atendimentos", { method: "POST", body: JSON.stringify(payload) });
      await refreshClientes();
      if (resultado.conflito) toast(resultado.conflito, "erro"); else toast(editando ? "Atendimento atualizado" : "Atendimento lançado");
      closeModal();
      if (document.getElementById("view-title").textContent === "Agenda") renderAgenda(); else renderAtendimentos();
    } catch (e) { erroEl.textContent = e.message; erroEl.classList.remove("hidden"); }
  });
}

/* ============================================================
   AGENDA
   ============================================================ */

let agendaMesRef = new Date();
let agendaDiaSelecionado = todayISO();

async function renderAgenda() {
  const root = document.getElementById("view-root");
  root.innerHTML = `
    <div class="calendar">
      <div class="calendar-head">
        <div class="period-nav">
          <button id="ag-prev" type="button">${ICON_L}</button>
          <span class="period-label" id="ag-mes-label"></span>
          <button id="ag-next" type="button">${ICON_R}</button>
        </div>
        <button id="ag-hoje" class="btn btn-secondary" type="button">Hoje</button>
      </div>
      <div class="calendar-grid" id="ag-grid"></div>
    </div>
    <div class="agenda-lista" id="ag-lista"></div>`;

  document.getElementById("ag-prev").addEventListener("click", () => { agendaMesRef = new Date(agendaMesRef.getFullYear(), agendaMesRef.getMonth() - 1, 1); renderAgenda(); });
  document.getElementById("ag-next").addEventListener("click", () => { agendaMesRef = new Date(agendaMesRef.getFullYear(), agendaMesRef.getMonth() + 1, 1); renderAgenda(); });
  document.getElementById("ag-hoje").addEventListener("click", () => { agendaMesRef = new Date(); agendaDiaSelecionado = todayISO(); renderAgenda(); });

  document.getElementById("ag-mes-label").textContent = capitalize(agendaMesRef.toLocaleDateString("pt-BR", { month: "long", year: "numeric" }));

  const mesKey = monthKeyOf(agendaMesRef);
  let counts = {};
  try { counts = await api(`/agenda/mes?mes=${mesKey}`); } catch (e) { toast(e.message, "erro"); }

  montarGradeCalendario(agendaMesRef, counts);
  await carregarDiaAgenda();
}

function montarGradeCalendario(mesRef, counts) {
  const grid = document.getElementById("ag-grid");
  const ano = mesRef.getFullYear(), mes = mesRef.getMonth();
  const primeiroDia = new Date(ano, mes, 1);
  const inicioGrade = new Date(ano, mes, 1 - ((primeiroDia.getDay() + 6) % 7)); // começa na segunda
  const dows = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
  let html = dows.map((d) => `<div class="dow">${d}</div>`).join("");

  for (let i = 0; i < 42; i++) {
    const d = new Date(inicioGrade.getFullYear(), inicioGrade.getMonth(), inicioGrade.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    const outroMes = d.getMonth() !== mes;
    const isHoje = iso === todayISO();
    const isSel = iso === agendaDiaSelecionado;
    const qtd = counts[iso] || 0;
    html += `<button type="button" class="calendar-day ${outroMes ? "outro-mes" : ""} ${isHoje ? "hoje" : ""} ${isSel ? "selecionado" : ""}" data-dia="${iso}">
      <span>${d.getDate()}</span>${qtd ? '<span class="dot"></span>' : ""}
    </button>`;
    if (outroMes && i >= 34) break; // não mostra a última linha se já for totalmente do mês seguinte
  }
  grid.innerHTML = html;
  grid.querySelectorAll("[data-dia]").forEach((b) => b.addEventListener("click", () => {
    agendaDiaSelecionado = b.dataset.dia;
    grid.querySelectorAll(".calendar-day").forEach((x) => x.classList.remove("selecionado"));
    b.classList.add("selecionado");
    carregarDiaAgenda();
  }));
}

async function carregarDiaAgenda() {
  const lista = document.getElementById("ag-lista");
  lista.innerHTML = `<div class="row-between"><h3>${escapeHtml(fmtData(agendaDiaSelecionado))}</h3>
    <button class="btn btn-primary" id="ag-novo">${ICON_PLUS} Novo atendimento</button></div>`;
  document.getElementById("ag-novo").addEventListener("click", async () => {
    await Promise.all([refreshClientes(), refreshProcedimentos()]);
    abrirFormAtendimento(null, agendaDiaSelecionado);
  });

  await Promise.all([refreshClientes(), refreshProcedimentos()]);
  let itens;
  try { itens = await api(`/agenda/dia?data=${agendaDiaSelecionado}`); }
  catch (e) { lista.insertAdjacentHTML("beforeend", `<p class="form-error">${escapeHtml(e.message)}</p>`); return; }

  if (!itens.length) { lista.insertAdjacentHTML("beforeend", emptyState("Nenhum atendimento nesse dia.")); return; }

  const wrap = document.createElement("div");
  wrap.innerHTML = itens.map((a) => `
    <div class="agenda-item" data-id="${a.id}">
      <div class="ai-hora">${a.horario}</div>
      <div class="ai-info">
        <strong>${escapeHtml(a.cliente_nome)} — ${escapeHtml(a.procedimento_nome)}</strong>
        <span>${a.duracao} min · ${fmtBRL(a.valor)} · ${PAGAMENTO_LABEL[a.forma_pagamento]}</span>
      </div>
      <span class="chip status-${a.status}">${STATUS_ATENDIMENTO_LABEL[a.status]}</span>
    </div>`).join("");
  Array.from(wrap.children).forEach((el, i) => el.addEventListener("click", () => abrirFormAtendimento(itens[i])));
  lista.appendChild(wrap);
}

/* ============================================================
   TRÁFEGO PAGO
   ============================================================ */

let trafegoOrdenar = "estado";

async function renderTrafego() {
  document.getElementById("topbar-actions").innerHTML = `<button class="btn btn-primary" id="novo-trafego">${ICON_PLUS} Novo público</button>`;
  document.getElementById("novo-trafego").addEventListener("click", () => abrirFormTrafego());

  const root = document.getElementById("view-root");
  root.innerHTML = `
    <div class="row-between" style="margin-bottom:16px;">
      <div class="field" style="margin:0; max-width:220px;">
        <label>Ordenar por</label>
        <select id="tp-ordenar">
          <option value="estado">Estado</option>
          <option value="preco">Preço (maior primeiro)</option>
          <option value="data">Data de lançamento (recente primeiro)</option>
          <option value="nome">Nome (A–Z)</option>
        </select>
      </div>
    </div>
    <div class="trafego-grid" id="tp-grid"></div>`;
  document.getElementById("tp-ordenar").value = trafegoOrdenar;
  document.getElementById("tp-ordenar").addEventListener("change", (e) => { trafegoOrdenar = e.target.value; carregarTrafego(); });
  await carregarTrafego();
}

async function carregarTrafego() {
  const grid = document.getElementById("tp-grid");
  let itens;
  try { itens = await api(`/trafego?ordenar=${trafegoOrdenar}`); }
  catch (e) { grid.innerHTML = `<p class="form-error">${escapeHtml(e.message)}</p>`; return; }
  if (!itens.length) { grid.innerHTML = emptyState("Nenhum público de tráfego pago lançado ainda."); return; }

  grid.innerHTML = itens.map((t) => `
    <div class="trafego-card estado-${t.estado}">
      <div class="tc-head">
        <div>
          <div class="tc-nome">${escapeHtml(t.nome)}</div>
          <div class="tc-meta">desde ${fmtData(t.data_lancamento)}</div>
        </div>
        <span class="chip status-${t.estado === "ativo" ? "concluido" : t.estado === "pausado" ? "pendente" : "cancelado"}">${ESTADO_TRAFEGO_LABEL[t.estado]}</span>
      </div>
      <div class="tc-gasto">${fmtBRL(t.gasto_diario)}<span class="faint" style="font-size:12px;"> /dia</span></div>
      <div class="tc-actions">
        <button class="btn btn-secondary" data-edit="${t.id}" type="button">${ICON_EDIT} Editar</button>
        <button class="btn btn-icon btn-secondary" data-del="${t.id}" type="button" aria-label="Excluir">${ICON_TRASH}</button>
      </div>
    </div>`).join("");

  grid.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => abrirFormTrafego(itens.find((i) => i.id == b.dataset.edit))));
  grid.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", async () => {
    if (await confirmar("Excluir esse público de tráfego pago?")) {
      try { await api(`/trafego/${b.dataset.del}`, { method: "DELETE" }); toast("Público excluído"); carregarTrafego(); }
      catch (e) { toast(e.message, "erro"); }
    }
  }));
}

function abrirFormTrafego(item) {
  const editando = !!item;
  const body = document.createElement("div");
  body.innerHTML = `
    <div id="tp-form-erro" class="form-error hidden"></div>
    <div class="field"><label>Nome do público</label><input type="text" id="tp-nome" value="${escapeHtml(editando ? item.nome : "")}"></div>
    <div class="field"><label>Gasto por dia (R$)</label><input type="number" min="0" step="0.01" id="tp-gasto" value="${editando ? item.gasto_diario : ""}"></div>
    ${editando ? `<div class="field"><label>Estado</label>
      <select id="tp-estado">${Object.entries(ESTADO_TRAFEGO_LABEL).map(([k, v]) => `<option value="${k}" ${item.estado === k ? "selected" : ""}>${v}</option>`).join("")}</select>
    </div>` : ""}
    <div class="modal-actions">
      <button class="btn btn-secondary" type="button" id="tp-cancel">Cancelar</button>
      <button class="btn btn-primary" type="button" id="tp-save">${editando ? "Salvar" : "Lançar público"}</button>
    </div>`;
  openModal(editando ? "Editar público" : "Novo público", body);
  body.querySelector("#tp-cancel").addEventListener("click", closeModal);
  body.querySelector("#tp-save").addEventListener("click", async () => {
    const erroEl = body.querySelector("#tp-form-erro");
    const nome = body.querySelector("#tp-nome").value.trim();
    if (!nome) { erroEl.textContent = "Informe o nome do público."; erroEl.classList.remove("hidden"); return; }
    const payload = { nome, gasto_diario: parseFloat(body.querySelector("#tp-gasto").value || "0") };
    if (editando) payload.estado = body.querySelector("#tp-estado").value;
    try {
      editando ? await api(`/trafego/${item.id}`, { method: "PUT", body: JSON.stringify(payload) })
               : await api("/trafego", { method: "POST", body: JSON.stringify(payload) });
      closeModal(); toast(editando ? "Público atualizado" : "Público lançado"); carregarTrafego();
    } catch (e) { erroEl.textContent = e.message; erroEl.classList.remove("hidden"); }
  });
}

/* ============================================================
   CATÁLOGO DE PROCEDIMENTOS
   ============================================================ */

async function renderProcedimentos() {
  document.getElementById("topbar-actions").innerHTML = `<button class="btn btn-primary" id="novo-proc">${ICON_PLUS} Novo procedimento</button>`;
  document.getElementById("novo-proc").addEventListener("click", () => abrirFormProcedimento());
  const root = document.getElementById("view-root");
  root.innerHTML = `<div id="proc-lista"></div>`;
  await carregarProcedimentos();
}

async function carregarProcedimentos() {
  const wrap = document.getElementById("proc-lista");
  const itens = await refreshProcedimentos();
  if (!itens.length) { wrap.innerHTML = emptyState("Nenhum procedimento cadastrado ainda."); return; }
  wrap.innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Procedimento</th><th class="num">Preço</th><th class="num">Duração</th><th></th></tr></thead>
    <tbody>${itens.map((p) => `<tr>
      <td>${escapeHtml(p.nome)}</td>
      <td class="num">${fmtBRL(p.preco_padrao)}</td>
      <td class="num">${p.duracao_padrao} min</td>
      <td style="white-space:nowrap;">
        <button class="btn btn-icon btn-secondary" data-edit="${p.id}" type="button" aria-label="Editar">${ICON_EDIT}</button>
        <button class="btn btn-icon btn-secondary" data-del="${p.id}" type="button" aria-label="Excluir">${ICON_TRASH}</button>
      </td>
    </tr>`).join("")}</tbody>
  </table></div>`;
  wrap.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => abrirFormProcedimento(itens.find((i) => i.id == b.dataset.edit))));
  wrap.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", async () => {
    if (await confirmar("Excluir esse procedimento do catálogo?")) {
      try { await api(`/procedimentos/${b.dataset.del}`, { method: "DELETE" }); toast("Procedimento excluído"); carregarProcedimentos(); }
      catch (e) { toast(e.message, "erro"); }
    }
  }));
}

function abrirFormProcedimento(item) {
  const editando = !!item;
  const body = document.createElement("div");
  body.innerHTML = `
    <div id="pr-form-erro" class="form-error hidden"></div>
    <div class="field"><label>Nome</label><input type="text" id="pr-nome" value="${escapeHtml(editando ? item.nome : "")}"></div>
    <div class="field-row">
      <div class="field"><label>Preço padrão (R$)</label><input type="number" min="0" step="0.01" id="pr-preco" value="${editando ? item.preco_padrao : ""}"></div>
      <div class="field"><label>Duração padrão (min)</label><input type="number" min="5" step="5" id="pr-duracao" value="${editando ? item.duracao_padrao : 30}"></div>
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" type="button" id="pr-cancel">Cancelar</button>
      <button class="btn btn-primary" type="button" id="pr-save">${editando ? "Salvar" : "Adicionar"}</button>
    </div>`;
  openModal(editando ? "Editar procedimento" : "Novo procedimento", body);
  body.querySelector("#pr-cancel").addEventListener("click", closeModal);
  body.querySelector("#pr-save").addEventListener("click", async () => {
    const erroEl = body.querySelector("#pr-form-erro");
    const nome = body.querySelector("#pr-nome").value.trim();
    if (!nome) { erroEl.textContent = "Informe o nome do procedimento."; erroEl.classList.remove("hidden"); return; }
    const payload = {
      nome,
      preco_padrao: parseFloat(body.querySelector("#pr-preco").value || "0"),
      duracao_padrao: parseInt(body.querySelector("#pr-duracao").value || "30", 10),
    };
    try {
      editando ? await api(`/procedimentos/${item.id}`, { method: "PUT", body: JSON.stringify(payload) })
               : await api("/procedimentos", { method: "POST", body: JSON.stringify(payload) });
      closeModal(); toast(editando ? "Procedimento atualizado" : "Procedimento adicionado"); carregarProcedimentos();
    } catch (e) { erroEl.textContent = e.message; erroEl.classList.remove("hidden"); }
  });
}

/* ============================================================
   CATÁLOGO DE CLIENTES
   ============================================================ */

async function renderClientes() {
  document.getElementById("topbar-actions").innerHTML = `<button class="btn btn-primary" id="nova-cliente">${ICON_PLUS} Nova cliente</button>`;
  document.getElementById("nova-cliente").addEventListener("click", () => abrirFormCliente());
  const root = document.getElementById("view-root");
  root.innerHTML = `
    <div class="field" style="max-width:280px;"><input type="search" id="cli-busca" placeholder="Buscar cliente…"></div>
    <div id="cli-lista" style="margin-top:14px;"></div>`;
  document.getElementById("cli-busca").addEventListener("input", (e) => carregarClientes(e.target.value));
  await carregarClientes("");
}

async function carregarClientes(filtro) {
  const wrap = document.getElementById("cli-lista");
  let itens;
  try { itens = await api("/clientes?resumo=1"); } catch (e) { wrap.innerHTML = `<p class="form-error">${escapeHtml(e.message)}</p>`; return; }
  cacheClientes = itens;
  const q = (filtro || "").trim().toLowerCase();
  const filtrados = q ? itens.filter((c) => c.nome.toLowerCase().includes(q)) : itens;
  if (!filtrados.length) { wrap.innerHTML = emptyState("Nenhuma cliente encontrada."); return; }

  wrap.innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Cliente</th><th class="num">Atendimentos</th><th class="num">Total gasto</th><th>Último atendimento</th><th></th></tr></thead>
    <tbody>${filtrados.map((c) => `<tr>
      <td>${escapeHtml(c.nome)}</td>
      <td class="num">${c.total_atendimentos}</td>
      <td class="num">${fmtBRL(c.total_gasto)}</td>
      <td class="muted">${c.ultimo_atendimento ? fmtData(c.ultimo_atendimento) : "—"}</td>
      <td style="white-space:nowrap;">
        <button class="btn btn-icon btn-secondary" data-edit="${c.id}" type="button" aria-label="Editar">${ICON_EDIT}</button>
        <button class="btn btn-icon btn-secondary" data-del="${c.id}" type="button" aria-label="Excluir">${ICON_TRASH}</button>
      </td>
    </tr>`).join("")}</tbody>
  </table></div>`;
  wrap.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => abrirFormCliente(filtrados.find((i) => i.id == b.dataset.edit))));
  wrap.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", async () => {
    if (await confirmar("Excluir essa cliente do catálogo?")) {
      try { await api(`/clientes/${b.dataset.del}`, { method: "DELETE" }); toast("Cliente excluída"); carregarClientes(document.getElementById("cli-busca").value); }
      catch (e) { toast(e.message, "erro"); }
    }
  }));
}

function abrirFormCliente(item) {
  const editando = !!item;
  const body = document.createElement("div");
  body.innerHTML = `
    <div id="cl-form-erro" class="form-error hidden"></div>
    <div class="field"><label>Nome</label><input type="text" id="cl-nome" value="${escapeHtml(editando ? item.nome : "")}"></div>
    <div class="modal-actions">
      <button class="btn btn-secondary" type="button" id="cl-cancel">Cancelar</button>
      <button class="btn btn-primary" type="button" id="cl-save">${editando ? "Salvar" : "Adicionar"}</button>
    </div>`;
  openModal(editando ? "Editar cliente" : "Nova cliente", body);
  body.querySelector("#cl-cancel").addEventListener("click", closeModal);
  body.querySelector("#cl-save").addEventListener("click", async () => {
    const erroEl = body.querySelector("#cl-form-erro");
    const nome = body.querySelector("#cl-nome").value.trim();
    if (!nome) { erroEl.textContent = "Informe o nome."; erroEl.classList.remove("hidden"); return; }
    try {
      editando ? await api(`/clientes/${item.id}`, { method: "PUT", body: JSON.stringify({ nome }) })
               : await api("/clientes", { method: "POST", body: JSON.stringify({ nome }) });
      closeModal(); toast(editando ? "Cliente atualizada" : "Cliente adicionada"); carregarClientes(document.getElementById("cli-busca").value);
    } catch (e) { erroEl.textContent = e.message; erroEl.classList.remove("hidden"); }
  });
}

/* ============================================================
   CONTAS A PAGAR
   ============================================================ */

let contasMes = monthKeyOf(new Date());

async function renderContas() {
  document.getElementById("topbar-actions").innerHTML = `<button class="btn btn-primary" id="nova-conta">${ICON_PLUS} Nova conta</button>`;
  document.getElementById("nova-conta").addEventListener("click", () => abrirFormConta());

  const root = document.getElementById("view-root");
  root.innerHTML = `
    <div class="period-nav" style="margin-bottom:16px;">
      <button id="ct-prev" type="button">${ICON_L}</button>
      <span class="period-label" id="ct-label"></span>
      <button id="ct-next" type="button">${ICON_R}</button>
    </div>
    <div id="ct-lista"></div>`;
  document.getElementById("ct-prev").addEventListener("click", () => { contasMes = addMonthKey(contasMes, -1); renderContas(); });
  document.getElementById("ct-next").addEventListener("click", () => { contasMes = addMonthKey(contasMes, 1); renderContas(); });
  const [y, m] = contasMes.split("-");
  document.getElementById("ct-label").textContent = capitalize(new Date(+y, +m - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" }));

  await carregarContas();
}

async function carregarContas() {
  const wrap = document.getElementById("ct-lista");
  let itens;
  try { itens = await api(`/contas?mes=${contasMes}`); } catch (e) { wrap.innerHTML = `<p class="form-error">${escapeHtml(e.message)}</p>`; return; }
  if (!itens.length) { wrap.innerHTML = emptyState("Nenhuma conta lançada nesse mês ainda."); return; }

  const total = itens.reduce((s, c) => s + c.valor, 0);
  wrap.innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Conta</th><th>Tipo</th><th class="num">Valor</th><th>Status</th><th></th></tr></thead>
    <tbody>${itens.map((c) => `<tr>
      <td>${escapeHtml(c.nome)}</td>
      <td class="muted">${c.fixa ? "Fixa" : "Avulsa"}</td>
      <td class="num">${fmtBRL(c.valor)}</td>
      <td>
        <select data-status="${c.id}" class="select-pill status-${c.status_pagamento}">
          ${Object.entries(STATUS_CONTA_LABEL).map(([k, v]) => `<option value="${k}" ${c.status_pagamento === k ? "selected" : ""}>${v}</option>`).join("")}
        </select>
      </td>
      <td style="white-space:nowrap;">
        <button class="btn btn-icon btn-secondary" data-edit="${c.id}" type="button" aria-label="Editar">${ICON_EDIT}</button>
        <button class="btn btn-icon btn-secondary" data-del="${c.id}" type="button" aria-label="Excluir">${ICON_TRASH}</button>
      </td>
    </tr>`).join("")}</tbody>
    <tfoot><tr><td colspan="2"><strong>Total do mês</strong></td><td class="num"><strong>${fmtBRL(total)}</strong></td><td colspan="2"></td></tr></tfoot>
  </table></div>`;

  wrap.querySelectorAll("[data-status]").forEach((sel) => sel.addEventListener("change", async (e) => {
    try { await api(`/contas/${sel.dataset.status}`, { method: "PUT", body: JSON.stringify({ status_pagamento: e.target.value }) }); toast("Status atualizado"); carregarContas(); }
    catch (err) { toast(err.message, "erro"); }
  }));
  wrap.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => abrirFormConta(itens.find((i) => i.id == b.dataset.edit))));
  wrap.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", async () => {
    if (await confirmar("Excluir essa conta?")) {
      try { await api(`/contas/${b.dataset.del}`, { method: "DELETE" }); toast("Conta excluída"); carregarContas(); }
      catch (e) { toast(e.message, "erro"); }
    }
  }));
}

function abrirFormConta(item) {
  const editando = !!item;
  const body = document.createElement("div");
  body.innerHTML = `
    <div id="ct-form-erro" class="form-error hidden"></div>
    <div class="field"><label>Nome da conta</label><input type="text" id="ct-nome" value="${escapeHtml(editando ? item.nome : "")}"></div>
    <div class="field"><label>Valor (R$)</label><input type="number" min="0" step="0.01" id="ct-valor" value="${editando ? item.valor : ""}"></div>
    <div class="checkbox-row"><input type="checkbox" id="ct-fixa" ${editando && item.fixa ? "checked" : ""}> <label for="ct-fixa">É uma conta fixa (repete todo mês)</label></div>
    <div class="modal-actions">
      <button class="btn btn-secondary" type="button" id="ct-cancel">Cancelar</button>
      <button class="btn btn-primary" type="button" id="ct-save">${editando ? "Salvar" : "Lançar conta"}</button>
    </div>`;
  openModal(editando ? "Editar conta" : "Nova conta", body);
  body.querySelector("#ct-cancel").addEventListener("click", closeModal);
  body.querySelector("#ct-save").addEventListener("click", async () => {
    const erroEl = body.querySelector("#ct-form-erro");
    const nome = body.querySelector("#ct-nome").value.trim();
    if (!nome) { erroEl.textContent = "Informe o nome da conta."; erroEl.classList.remove("hidden"); return; }
    const payload = { nome, valor: parseFloat(body.querySelector("#ct-valor").value || "0"), fixa: body.querySelector("#ct-fixa").checked };
    if (!editando) payload.mes_referencia = contasMes;
    try {
      editando ? await api(`/contas/${item.id}`, { method: "PUT", body: JSON.stringify(payload) })
               : await api("/contas", { method: "POST", body: JSON.stringify(payload) });
      closeModal(); toast(editando ? "Conta atualizada" : "Conta lançada"); carregarContas();
    } catch (e) { erroEl.textContent = e.message; erroEl.classList.remove("hidden"); }
  });
}

/* ============================================================
   LEMBRETES (15 minutos antes)
   ============================================================ */

function atualizarBotaoNotif() {
  const btn = document.getElementById("notif-btn");
  const label = document.getElementById("notif-btn-label");
  if (!("Notification" in window)) { btn.classList.add("hidden"); return; }
  if (Notification.permission === "granted") { btn.classList.add("on"); label.textContent = "Lembretes ativados"; }
  else { btn.classList.remove("on"); label.textContent = "Ativar lembretes"; }
}

async function checarLembretes() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  let itens;
  try { itens = await api("/agenda/proximos"); } catch (e) { return; }
  const agora = new Date();
  for (const a of itens) {
    if (a.notificado_em) continue;
    const inicio = new Date(`${a.data}T${a.horario}:00`);
    const minutos = (inicio - agora) / 60000;
    if (minutos <= 15 && minutos > -30) {
      new Notification("Studio Mendes Essence", {
        body: `Não se esqueça do atendimento de ${a.procedimento_nome} com ${a.cliente_nome}, hoje às ${a.horario}, daqui a 15 minutos!`,
        icon: "static/icons/icon-192.png",
      });
      try { await api(`/atendimentos/${a.id}/notificado`, { method: "POST" }); } catch (e) { /* tenta de novo depois */ }
    }
  }
}

/* ============================================================
   INSTALAÇÃO COMO APP (PWA)
   ============================================================ */

let deferredInstallPrompt = null;

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  const btn = document.getElementById("install-btn");
  if (btn) btn.classList.remove("hidden");
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  const btn = document.getElementById("install-btn");
  if (btn) btn.classList.add("hidden");
  toast("App instalado! Agora é só abrir pelo ícone.");
});

/* ============================================================
   BOOT
   ============================================================ */

document.addEventListener("DOMContentLoaded", async () => {
  await loadStore();
  document.querySelectorAll(".nav-item").forEach((btn) => btn.addEventListener("click", () => goTo(btn.dataset.view)));

  document.getElementById("menu-toggle").addEventListener("click", () => {
    document.getElementById("sidebar").classList.add("open");
    document.getElementById("sidebar-scrim").classList.add("show");
  });
  document.getElementById("sidebar-scrim").addEventListener("click", closeSidebarMobile);

  document.getElementById("install-btn")?.addEventListener("click", async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    document.getElementById("install-btn").classList.add("hidden");
  });

  document.getElementById("notif-btn").addEventListener("click", async () => {
    if (!("Notification" in window)) { toast("Esse navegador não permite notificações.", "erro"); return; }
    if (Notification.permission === "default") await Notification.requestPermission();
    atualizarBotaoNotif();
    if (Notification.permission === "denied") toast("As notificações estão bloqueadas nas permissões do navegador.", "erro");
  });
  atualizarBotaoNotif();

  window.addEventListener("online", () => setOnline(true));
  window.addEventListener("offline", () => setOnline(false));

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  }

  goTo("dashboard");

  checarLembretes();
  setInterval(checarLembretes, 30000);
});
