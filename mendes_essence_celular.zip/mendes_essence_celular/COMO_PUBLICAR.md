# Como colocar essa pasta no ar (celular)

Essa pasta (`mendes_essence_celular`) é um app completo que roda sozinho, sem
servidor nenhum — cada aparelho guarda os próprios dados. Só precisa estar
hospedada num endereço de internet pra virar instalável de verdade (é regra
de segurança dos navegadores, não tem como pular essa etapa).

Vamos usar o **GitHub Pages** — hospedagem de graça, para sempre, sem cartão
de crédito.

## Parte 1 — Colocar os arquivos no ar (GitHub Pages)

1. Acesse **github.com** e crie uma conta grátis (só precisa de um e-mail).
2. Clique no **+** no canto superior direito → **"New repository"**.
   - Nome: `mendes-essence` (ou o que preferir, sem espaços)
   - Marque como **Public**
   - Clique em **"Create repository"**
3. Na página do repositório, clique em **"uploading an existing file"**
   (ou "Add file" → "Upload files").
4. Arraste **todo o conteúdo de dentro** da pasta `mendes_essence_celular`
   (o `index.html`, o `manifest.json`, a pasta `static`, tudo) — não a pasta
   em si, o que está *dentro* dela.
5. Clique em **"Commit changes"** lá embaixo.
6. Vá em **Settings** (menu do repositório) → **Pages** (barra lateral
   esquerda) → em "Branch" escolha **main** → **Save**.
7. Espere 1-2 minutos e atualize a página. Vai aparecer um link tipo:
   ```
   https://seu-usuario.github.io/mendes-essence/
   ```
   **Esse é o endereço do app.** Guarde ele — é o mesmo pra todo mundo da
   família usar.

## Parte 2 — Instalar no iPhone

1. Abra esse link no **Safari** (tem que ser o Safari, não funciona certo
   em outro navegador no iPhone).
2. Toque no ícone de compartilhar (□ com uma seta pra cima).
3. Toque em **"Adicionar à Tela de Início"**.

Pronto — vira um ícone na tela, abre em tela cheia, sem barra de navegador
aparecendo. É o mais próximo de um app nativo que a Apple permite de graça.

## Parte 3 — Gerar o instalador Android (.apk de verdade)

1. Acesse **pwabuilder.com**.
2. Cole o link do GitHub Pages (o do passo 7 da Parte 1) e clique na seta.
3. Espere ele analisar (uns 15-30 segundos).
4. Clique em **"Package for stores"** → escolha **Android**.
5. Pode deixar as opções como estão → clique em **"Generate"**.
6. Baixa um arquivo `.apk` (ou um `.zip` com o `.apk` dentro).

Transfira esse `.apk` pro celular Android (por WhatsApp Web, Google Drive,
cabo USB — o que for mais fácil) e toque nele pra instalar. Na primeira vez,
o Android vai avisar "instalar apps de fontes desconhecidas" — é normal,
só confirma. Depois disso, o app fica instalado que nem qualquer outro,
com ícone no menu de aplicativos, e pode até desinstalar depois se quiser.

## Importante: os dados não se juntam entre os aparelhos

Cada instalação — o iPhone, o Android, e cada computador com o app desktop
— guarda os dados só ali, no próprio aparelho. Não sincroniza entre eles.
Foi essa a opção escolhida (mais simples, mais barato, sem depender de
servidor nenhum ligado). Se um dia precisar que todos vejam os mesmos
dados em tempo real, aí sim precisaria de outro tipo de solução (com
custo e complexidade bem maiores).

## Atualizações

Se no futuro eu mandar uma versão nova dessa pasta, o processo é repetir a
Parte 1 (subir os arquivos novos por cima, no mesmo repositório) — o link
continua o mesmo, e quem já instalou recebe a atualização sozinho na
próxima vez que abrir com internet (graças ao "service worker" que já vem
configurado).
