const CACHE_NAME = "mendes-essence-celular-v1";

const APP_SHELL = [
  "./",
  "./index.html",
  "./static/css/app.css",
  "./static/js/app.js",
  "./static/js/local_backend.js",
  "./static/img/logo-mark.png",
  "./static/icons/icon-192.png",
  "./static/icons/icon-512.png",
  "./manifest.json",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  // Tudo aqui é local (dados ficam no localStorage do aparelho, não em API) —
  // então é sempre cache-first com atualização em segundo plano.
  event.respondWith(
    caches.match(req).then((cached) => {
      const fetchPromise = fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          return res;
        })
        .catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
